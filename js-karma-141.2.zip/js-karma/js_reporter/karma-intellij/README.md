Reporter for IntelliJ / WebStorm.
